import Doctors from "../models/DoctorModel.js";

export const createDoctor = async (req, res) => {};
